# runners
## sooo sooo wip

- download needed requirements
- make a source file or find existing one (any supported language works)
- right click and select 'open with'
- select 'choose another app'
- scroll down and select 'choose an app on your pc'
- navigate to where your source runner is (download them here)
- select it and click 'always'
- now double click your source file. it will create the needed requirements (example pdb or class files) so you may need to run it twice the first time. but after that, its all good.
- enjoy